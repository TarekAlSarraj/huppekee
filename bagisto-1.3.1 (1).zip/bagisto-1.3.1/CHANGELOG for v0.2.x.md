# CHANGELOG for v0.2.x

#### This changelog consists the bug & security fixes and new features being included in the releases listed below.

## **v0.2.0 (23th of December, 2019)** - *Release*

* #1955 [fixed] - Message need to be changed on mouse hover on cross symbol next to applied coupon.

* #1959 [fixed] - if admin has set the same condition twice, then catalog rule is not getting apply

* #1958 [fixed] - getting exception on front end, if action type is Buy x get y free in non couponable cart rule.

* #1957 [fixed] - if action type is Fixed Amount to Whole Cart, then apply to shipping option should get hide.

* #1954 [fixed] - If any different tax category has been assigned to variants in configurable product, then while using tax category condition in cart rule, rule is not working properly.

* #1950 [fixed] - multiple catalog rule should not get get applied, if 1st one has been created as End Other Rules = yes