<?php

namespace Webkul\BookingProduct\Models;

use Konekt\Concord\Proxies\ModelProxy;

class BookingProductEventTicketTranslationProxy extends ModelProxy
{

}