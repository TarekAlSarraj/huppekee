<?php

namespace Webkul\BookingProduct\Contracts;

interface BookingProduct
{
}