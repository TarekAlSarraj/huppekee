<?php

namespace Webkul\Attribute\Contracts;

interface AttributeFamily
{
}