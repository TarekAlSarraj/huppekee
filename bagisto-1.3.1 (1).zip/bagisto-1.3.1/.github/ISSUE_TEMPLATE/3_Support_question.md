---
name: "❔ Support Question"
about: 'This repository is only for reporting bugs or problems. If you need help, see:
  https://github.com/bagisto/bagisto#documentation'
---

This repository is only for reporting bugs or issues. If you need support, please use:

1. Create support ticket on https://bagisto.uvdesk.com

Thanks!
